package com.zoo;

public class ZooTest {

	public static void main(String[] args) {
		Gorilla gorilla = new Gorilla();
		gorilla.throwSomething();
		gorilla.throwSomething();
		gorilla.eatBananas();
		gorilla.climb();
		gorilla.displayEnergy();
	}
}
